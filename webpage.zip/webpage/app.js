document.getElementById('uploadButton').addEventListener('click', async () => {
    const fileInput = document.getElementById('fileInput');
    if (!fileInput.files.length) {
        alert('Please select a file to upload');
        return;
    }
    const file = fileInput.files[0];

    try {
        // Fetch the presigned URL in LAMBDA (transcoder-lambda function)
        const response = await fetch('https://efcm3z656k.execute-api.us-east-1.amazonaws.com/deploy/transcoder-lambda', {
            method: 'GET'
        });
        const data = await response.json();

     
        const uploadResponse = await fetch(data.url, {
            method: 'PUT',
            body: file // Content-Type header removed
        });

        if (uploadResponse.ok) {
            alert('File uploaded successfully');
        } else {
            console.log(uploadResponse.status, uploadResponse.statusText);
            alert('Upload failed');
        }
    } catch (error) {
        console.error('Error uploading file:', error);
        alert('Error uploading file');
    }
});
